/**
 * Created by Administrator on 2015-02-04.
 */
var easyimg = require('easyimage');
var path = require('path');
var fse = require('fs-extra');
exports.uploadfunc_join = function(files,email){
    var originalname = files.originalname;
    var rename = email+"_"+originalname;
//    var photoname = rename;
//    var name = files.name;

    var srcImg = files.path;

    var originPath = path.join(__dirname,'..','public','photo','users',rename);
    var origin = "/photo/users/"+rename;
    fse.move(srcImg,originPath,0, function(err) {
            if (err) return console.error(err)
            console.log("success!");
        }
    );


    var idx = rename.lastIndexOf('.');
    var tempName = rename.substring(0,idx);
    var ext = rename.substring(idx);
    rename = tempName + '_thumbnail' + ext;
    var dstPath = path.join(__dirname,'..','public','photo','users','thumbnail',rename);
    var thumbnail = "/photo/users/thumbnail/"+rename;
    console.log(dstPath);
    easyimg.thumbnail({
        src:originPath,dst: dstPath,
        width:128,height:128,
        x:0,y:0
    }).then(function(file){
        console.log('file',file);
    });
    var arr = {};
    arr.origin = origin;
    arr.thumbnail = thumbnail;
    return arr;
};





exports.uploadfunc_course = function(files){
    var photo_org_name = files.originalname;
    var idx = photo_org_name.lastIndexOf('.');
    var tempName = photo_org_name.substring(0,idx);
    var ext = photo_org_name.substring(idx);
    var unique =  Date.now();
    var photo_name = tempName+unique+ext;

    var srcImg = files.path;

    var originPath = path.join(__dirname,'..','public','photo','course',photo_name);
    var origin = "/photo/course/"+photo_name;
    fse.move(srcImg,originPath,0, function(err) {
            if (err) return console.error(err)
            console.log("success!");
        }
    );


    var idx = photo_org_name.lastIndexOf('.');
    var tempName = photo_org_name.substring(0,idx);
    var ext = photo_org_name.substring(idx);
    var photo_thumbnail = tempName + '_thumbnail' + unique+ext;
    var dstPath = path.join(__dirname,'..','public','photo','course','thumbnail',photo_thumbnail);
    var thumbnail = "/photo/course/thumbnail/"+photo_thumbnail;
    console.log(dstPath);
    easyimg.thumbnail({
        src:originPath,dst: dstPath,
        width:128,height:128,
        x:0,y:0
    }).then(function(file){
        console.log('file',file);
    });
    var arr = {};
    arr.photo = origin;
    arr.photo_org_name = photo_org_name;
    arr.thumbnail = thumbnail;
    return arr;
};