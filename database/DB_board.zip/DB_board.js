var mysql = require('./DB_config');
var sql = require('./sqls');
var pool  = mysql.pool;
var _ = require('lodash');
var async = require('async');

exports.main = function(values,callback){
    //values = email, page
    var email = values.logined;
    var page = values.page;
    var limit_num = (values.page-1)*10;
    var size = 2;
    var send_message = {};
    send_message.recommend = [ ];
    //recommend user 1명 가져오기

    var success = true;
    pool.getConnection(function(err,connection){
        if(err) {
            console.error('err',err);
            success = false;
        }
        async.parallel({
//            function(callback){
//                if(page == 1) {
//                    connection.query(sql.recommend_user, [email, email, email, email, email, 0, size], function (err, rows, result) {
//                        if (err) {
//                            console.error('err', err);
//                            success = false;
//                        }
//                        console.log(rows);
//                        callback(null, rows[0]);
//                    });
//                }
//            },
            "recommends": function (callback) {
                console.log(1);
                if (page == 1) {
                    connection.query(sql.recommend_tutor, [email, email, email, email, 0, size], function (err, rows, result) {
                        if (err) {
                            console.error('err', err);
                            success = false;
                        }
                        if (rows.length) {
                            target = rows[0].email;
                            connection.query(sql.getSubject, [target], function (err, subjects, result) {
                                if (err) {
                                    console.error('err', err);
                                    success = false;
                                }
                                rows[0].subjects = sql.to_array(subjects, "subjects").subjects;
                                callback(null, rows);
                            });
                        }
                    });
                } else callback(null);
            },
            "state":function(callback)
            {
                if (page == 1) {
                    connection.query(sql.relation_alram, [email], function (err, rows, result) {
                        if (err) {
                            console.error('err', err);
                            success = false;
                        }
                        callback(null, rows);
                    });
                } else callback(null);
            }
            ,
//            사용자 이메일,사용자 이메일,사용자 이메일,사용자 이메일,사용자 이메일,페이지
            "boards":function (callback) {
                connection.query(sql.getFeed, [email, email, email, email, email, limit_num], function (err, rows, result) {
                    if (err) {
                        console.error('err', err);
                        success = false;
                    }
//                    if (rows.length) {
//                        send_message.boards = rows;
//                    }
                    callback(null, rows);
                    console.log('boards', send_message.boards);
                })
            }
        },function(err, result){
            connection.release();
            if(err || !success) {
                console.error('err',err);
                callback(sql.fail);
            } else{
                result.isSuccess = 1;
                console.log(result);
                callback(result);
            }
        });

    });
    // console.log('req.body = '+req.body);
};


exports.list = function(values,callback){
    var limit_num = (values.page-1)*10;
    var target = values.email;
    var email = values.logined;
    var success = true;
    pool.getConnection(function(err,connection){
        if(err) {
            console.error('err',err);
            success = false;
        }
        connection.query(sql.board_list,[email,target, 0, limit_num],function(err,rows,result){
            connection.release();
            if(err || !success){
                console.error('err',err);
                callback(sql.fail);
            } else {
                rows.isSuccess = 1;
                console.log(rows);
                callback(rows);
            }
        });
    });
};



exports.read = function(values,callback){
    var num = values.num;
    var email = values.logined;
    var send_message ={};
    var success = true;
    pool.getConnection(function(err,connection){
        if(err) console.error('err',err);
        async.parallel({
            "board":function(callback){
                connection.query(sql.read_article,[email, num],function(err,rows,result){
                    if(err) console.error('err',err);
                    if(rows.length){
                        console.log(rows);
//                send_message.board = rows[0];
                        connection.query(sql.read_photo,[num],function(err,photos,result) {
                            console.log(send_message);
                            rows[0].photo = sql.to_array(photos, "photo").photo;
                            callback(null,rows[0]);
                        });
                    }
                })
            },
            "board_comments" :function(callback){
                connection.query(sql.read_comments,[num],function(err,rows,result){
                    if(err) console.error('err',err);
                    console.log(rows);
                    callback(null,rows);
                });
            }
    },function(err,result){
            connection.release();
            if(err || !success) {
                console.error('err',err);
                callback(sql.fail);
            } else{
                result.isSuccess = 1;
                console.log(result);
                callback(result);
            }
        });
    });
};


exports.write = function(values,callback){
    console.log("db들어옴")
    var inputs = {};
    inputs.email = values.logined;
    inputs.title = values.title;
    inputs.content = values.content;
    inputs.url1 = values.url1;
    inputs.url2 = values.url2;

    console.log(inputs);
    pool.getConnection(function(err,connection) {

        connection.query(sql.insert_board, /*[values.logined,values.title,values.content,values.url1,values.url2]*/inputs, function (err, result) {
            console.log(result);
            var message
            if (err || !result.affectedRows) {
                console.error('err', err);
                message = sql.fail

            } else message = sql.success;

            connection.release();
            callback(message);
        });
    });
}


exports.modify = function(values,callback){
    console.log("db들어옴")
    var inputs = {};
    inputs.num = values.num;
    inputs.email = values.logined;
    inputs.title = values.title;
    inputs.content = values.content;
    inputs.url1 = values.url1;
    inputs.url2 = values.url2;

    console.log(inputs);
    pool.getConnection(function(err,connection) {

        connection.query(sql.modify_board, [values.title,values.content,values.url1, values.url2,values.num,values.logined], function (err, result) {
            console.log(result);
            var message
            if (err || !result.affectedRows) {
                console.error('err', err);
                message = sql.fail

            } else message = sql.success;

            connection.release();
            callback(message);
        });
    });
}


exports.delete = function(values,callback){
    console.log("db들어옴")
    var inputs = {};
    inputs.num = values.num;
    inputs.email = values.logined;

    console.log(inputs);
    pool.getConnection(function(err,connection) {

        connection.query(sql.delete_board, [values.num,values.logined], function (err, result) {
            console.log(result);
            var message
            if (err || !result.affectedRows) {
                console.error('err', err);
                message = sql.fail

            } else message = sql.success;

            connection.release();
            callback(message);
        });
    });
}



exports.write_comment = function(values,callback){
    console.log("db들어옴")
    var inputs = {};
    inputs.email = values.logined;
    inputs.grp = values.grp;
    inputs.content = values.content;


    console.log(inputs);
    pool.getConnection(function(err,connection) {

        connection.query(sql.insert_comment,[values.grp,values.grp,values.logined,values.content], function (err, result) {
            console.log(result);
            var message
            if (err || !result.affectedRows) {
                console.error('err', err);
                message = sql.fail

            } else message = sql.success;

            connection.release();
            callback(message);
        });
    });
}


exports.modify_comment = function(values,callback){
    console.log("db들어옴")
    var inputs = {};
    inputs.email = values.logined;
    inputs.grp = values.grp;
    inputs.grp_num = values.grp_num;
    inputs.content = values.content;


    console.log(inputs);
    pool.getConnection(function(err,connection) {

        connection.query(sql.modify_comment,[values.content,values.grp,values.grp_num,values.logined], function (err, result) {
            console.log(result);
            var message
            if (err || !result.affectedRows) {
                console.error('err', err);
                message = sql.fail

            } else message = sql.success;

            connection.release();
            callback(message);
        });
    });
}


exports.delete_comment = function(values,callback){
    console.log("db들어옴")
    var inputs = {};
    inputs.email = values.logined;
    inputs.grp = values.grp;
    inputs.grp_num = values.grp_num;
    inputs.content = values.content;


    console.log(inputs);
    pool.getConnection(function(err,connection) {

        connection.query(sql.delete_comment,[values.grp,values.grp_num,values.logined], function (err, result) {
            console.log(result);
            var message
            if (err || !result.affectedRows) {
                console.error('err', err);
                message = sql.fail

            } else message = sql.success;

            connection.release();
            callback(message);
        });
    });
}

